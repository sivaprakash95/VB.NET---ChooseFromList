﻿#Region "Imports"
Imports System.Windows.Forms
Imports System.Data.SqlClient
#End Region

Public Class CFL

#Region "Declaration"
    Public con As SqlConnection
    Public da As SqlDataAdapter
    Public dt As DataTable
    Public ColumnValue() As String
#End Region

#Region "User Function"
    Public Sub FunLoadCFL(ByVal str_query As String, ByVal left As Integer, ByVal Top As Integer, Optional ByVal frm_Width As Integer = 400, Optional ByVal frm_Height As Integer = 200)
        Me.StartPosition = FormStartPosition.Manual
        Me.DesktopLocation = New Point(left, Top)
        Me.Width = frm_Width : Me.Height = frm_Height
        Me.KeyPreview = True
        dgvload.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvload.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvload.AllowUserToAddRows = False
        dgvload.AllowUserToDeleteRows = False

        dt = New DataTable
        dt = FunFillDT(str_query)
        If dt.Rows.Count > 0 Then
            dgvload.DataSource = Nothing
            dgvload.DataSource = dt
            dgvload.Columns(0).DefaultCellStyle.Font = New Font(FontFamily.GenericSansSerif, 9, FontStyle.Bold)
        End If
        txtsearch.Text = ""
        Me.ShowDialog()
    End Sub

    Private Sub FunSearch(ByVal searchtext As String)
        Try
            If txtsearch.Text.Trim() <> "" Then
                For i As Integer = 0 To dgvload.RowCount - 1
                    If Char.ToUpper(dgvload.Rows(i).Cells(0).Value.ToString) = Char.ToUpper(txtsearch.Text) Then
                        dgvload.Rows(i).Selected = True
                        dgvload.CurrentCell = dgvload.Item(0, i)
                    End If
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub FunSaveSelection()
        Try
            ReDim ColumnValue(dgvload.ColumnCount)
            For i As Integer = 0 To dgvload.ColumnCount - 1
                ColumnValue(i) = dgvload.Rows(dgvload.CurrentCell.RowIndex).Cells(i).Value.ToString()
            Next
            Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub
    Public Function FunFillDT(ByVal str_query As String) As Object
        Try
            If IsNothing(con) Then
                FunConnectDB()
            End If
            dt = New DataTable
            da = New SqlDataAdapter(str_query, con)
            da.Fill(dt)
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
        Return dt
    End Function

    Sub FunConnectDB()
        Try
            If Not IsNothing(con) Then
                con = Nothing
            End If
            con = New SqlConnection("DATA SOURCE = 'DESKTOP-074SEAB'; INTEGRATED SECURITY = false; INITIAL CATALOG = 'Items'; USER ID ='sa'; PASSWORD ='sql@123';")
            con.Open()
            con.Close()
        Catch ex As Exception
            MsgBox("Connection error Check service  : " + vbNewLine + ex.ToString(), , "SQL CONNCETION ERROR")
        End Try
    End Sub
#End Region

#Region "Events"
    Private Sub dgvload_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvload.CellClick
        FunSaveSelection()
    End Sub

    Private Sub txtsearch_TextChanged(sender As Object, e As EventArgs) Handles txtsearch.TextChanged
        FunSearch(txtsearch.Text)
    End Sub

    Private Sub CFL_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Escape Then
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
            Me.Close()
        End If
    End Sub
#End Region

End Class