﻿Public Class MyForm

    Private Sub txtitem_Click(sender As Object, e As EventArgs) Handles txtitem.Click
        Dim xleft As Integer = Me.Location.X + txtitem.Location.X + 20
        Dim ytop As Integer = Me.Location.Y + txtitem.Location.Y + txtitem.Height + 35
        CFL.FunLoadCFL("select * from item", xleft, ytop)
        If Not IsNothing(CFL.ColumnValue) Then
            txtitem.Text = CFL.ColumnValue(0)
            txtcode.Text = CFL.ColumnValue(1)
            txtprice.Text = CFL.ColumnValue(2)
            txtunit.Text = CFL.ColumnValue(3)
        End If
    End Sub
End Class
